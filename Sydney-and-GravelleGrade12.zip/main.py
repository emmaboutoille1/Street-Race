""" 
Sydney & Emma
11/18/2021 - 12/12/2021
A4.1 Street Racer

                      Notable Mentions:

Press the "s" key to change your car colour. (Yellow, Pink, & Orange)

Use "a" and "d" keys to navigate.

Collect Gas Cans to prolong your playtime.

Collect Tools to get a higher score. 

"""

#------------------------ Import -----------------------------
import random #import library
import turtle #import library
import time #import library
#------------------------ Window Setup -----------------------
wn = turtle.Screen() #create window called wn
wn.setup(width=1.0, height=1.0,startx=None,starty=None) #maximize screensize
wn.setup(height=800,width=600) #set window size
wn.title("A4.2 Street Racer") #window title
wn.register_shape("roadO.gif") #register shape
wn.bgpic("roadO.gif") #set bg
wn.tracer(0) #tracer

#----------------------Register Shapes ----------------------------
#Player Car States (Lots of damage/Fair bit/Small amount/None)
wn.register_shape("verydmg2.gif") #register shape
wn.register_shape("baddmg.gif") #register shape
wn.register_shape("dmg.gif") #register shape
wn.register_shape("norm.gif") #register shape
wn.register_shape("orangeverydmg2.gif") #register shape
wn.register_shape("orangebaddmg.gif") #register shape
wn.register_shape("orangedmg.gif") #register shape
wn.register_shape("orangenorm.gif") #register shape
wn.register_shape("pinkverydmg2.gif") #register shape
wn.register_shape("pinkbaddmg.gif") #register shape
wn.register_shape("pinkdmg.gif") #register shape
wn.register_shape("pinknorm.gif") #register shape
wn.register_shape("bluecar.gif") #register shape
wn.register_shape("heart.gif") #register shape
wn.register_shape("limecar.gif") #register shape
wn.register_shape("purplecar.gif") #register shape
wn.register_shape("skycar.gif") #register shape
wn.register_shape("redcar.gif") #register shape
wn.register_shape("tool.gif") #register shape
wn.register_shape("gasindicatorfull.gif") #register shape
wn.register_shape("gasindicator2.gif") #register shape 
wn.register_shape("gasindicator3.gif") #register shape 
wn.register_shape("gasindicator4.gif") #register shape 
wn.register_shape("gasindicatorhalf.gif") #register shape
wn.register_shape("gasindicator6.gif") #register shape
wn.register_shape("gasindicator7.gif") #register shape
wn.register_shape("gasindicator8.gif") #register shape
wn.register_shape("gasindicatorempty.gif") #register shape
wn.register_shape("planterbox.gif") #register shape
wn.register_shape("policecar.gif") #register shape
wn.register_shape("lamp.gif") #register shape
wn.register_shape("lampR.gif") #register shape
wn.register_shape("gascan.gif") #register shape

#----------------------Turtle Setup ----------------------------
camera_dy = 0 #set camera x value
camera_y = 0 #set camera y value
start_time = time.time() #get game start time

lives = 3 #set base lives
car_state = ["verydmg2.gif","baddmg.gif","dmg.gif","norm.gif"] #establish list
orangecar_state = ["orangeverydmg2.gif","orangebaddmg.gif","orangedmg.gif","orangenorm.gif"] #establish list
pinkcar_state = ["pinkverydmg2.gif","pinkbaddmg.gif","pinkdmg.gif","pinknorm.gif"] #establish list
enemy_colours = ["purplecar.gif","limecar.gif","bluecar.gif","skycar.gif","redcar.gif"] #establish list
lane_x = [-450,-180,180,450] #create list of lanes (up & down)
up_lane = [-450,180] #create list of lanes (up)
down_lane = [-180,450] #create list of lanes (down)
many_lives = [] #create empty list
many_tools = [] #create empty list
many_enemies = [] #create empty list
many_plants = [] #create empty list
many_lamps = [] #create empty list
many_cans = [] #create empty list
int_score = 0 #set score start
change = "yellow" #set starting colour
change_count = 0 #set change count start
int_gas = 40 #set variable
gas_levels = ["gasindicatorfull.gif", "gasindicator2.gif", "gasindicator3.gif", "gasindicator4.gif", "gasindicatorhalf.gif", "gasindicator6.gif", "gasindicator7.gif", "gasindicator8.gif", "gasindicatorempty.gif"] #establish list
#----------------------Turtle Setup ----------------------------

path=turtle.Turtle()#create path turtle
path.pu()#pen up
path.shape("roadO.gif") #set colour

pen = turtle.Turtle() # turtle to write
pen.ht() #hide turtle
pen.pu() #pen up
pen.goto(25,280) #go to x y
pen.color("white") #set colour
penstyle = ("New Times Roman", 20, "italic") #Set text style

player=turtle.Turtle() #est player
player.shape(car_state[3]) #set shape to (120x120 pixels)
player.setheading(90) #set heading
player.pu() #pen up
player.goto(0,-200) #go to the bottom of the screen
player.direction = "stop" #initialize player direction

timepen = turtle.Turtle() #create a pen turtle to write the time 
timepen.ht() # hide turtle 
timepen.pu() #pen up
timepen.goto(0,300) #go to 0,300
timepen.color("white") #set colour to white
penstyle_time = ("New Times Roman", 20) #set text style for the time

police = turtle.Turtle() #create a police turtle
police.shape("policecar.gif") #set shape to policecar 
police.pu() #pen up
police.ht() #hide turtle

for i in range(8): #execute code x8
  enemy = turtle.Turtle() #est enemy (cars) turtle
  car_colour = random.choice(enemy_colours) #select random car colour
  enemy.shape(car_colour) #set shape to car sp colour (120x120 pixels)
  
  enemy.pu() #pen up

  if i <=4:
    ranx = random.choice(down_lane) #select random spawn lane
  if i >=5:
    ranx = random.choice(up_lane) #select random spawn lane
  enemy.setx(ranx) #go to the bottom of the screen
  enemy.sety(300) #move y cord down
  enemy.speed = random.randint(1,4) #set speed

  many_enemies.append(enemy) #add turtle to many_lives list

for i in range(3):
  tool = turtle.Turtle() #set tool point turtle
  tool.shape("tool.gif") #set shape to car sp colour (120x120 pixels)

  tool.pu() #pen up
  ranx = random.choice(lane_x) #select random spawn lane
  tool.setx(ranx) #go to the bottom of the screen
  tool.sety(300) #move y cord down
  tool.speed = random.randint(1,6) #set speed

  many_tools.append(tool) #add turtle to many_tools list

for i in range(6):
  gas_can = turtle.Turtle() #set gas can turtle
  gas_can.shape("gascan.gif") #set shape to car sp colour (120x120 pixels)
  gas_can.pu() #pen up
  ranx = random.choice(lane_x) #select random spawn lane
  gas_can.setx(ranx) #go to the bottom of the screen
  gas_can.sety(300) #move y cord down
  gas_can.speed = random.randint(2,6) #set speed

  many_cans.append(gas_can) #add turtle to many_cans list

for i in range(3):
  life = turtle.Turtle() #set life heart turtle
  life.shape("heart.gif") #set shape to heart (40x40 pixels)
  life.pu() #pen up
  life.setx(15) #go to the bottom of the screen
  life.sety(260-50*i) #move y cord down

  many_lives.append(life) #add turtle to many_lives list

for i in range(3):
  plant = turtle.Turtle() #set planter box background turtle
  plant.shape("planterbox.gif") #set shape to planterbox (60x90 pixels)
  plant.pu() #pen up
  plant.setx(15) #go to the bottom of the screen
  plant.sety(300-200*i) #move y cord down

  many_plants.append(plant) #add turtle to many_plants list


for i in range(6):
  lightpost = turtle.Turtle() #est lightpost background turtle
  lightpost.pu() #pen up
  
  if i <=2:
    x_val = -520 #left
    lightpost.shape("lamp.gif") #set shape to lightpost
    y_val=400 #set y val
    lightpost.sety(y_val-200*i) #move y cord down 
  elif i >=3:
    x_val = 520 #right
    lightpost.shape("lampR.gif") #set shape to lightpost 
    y_val=400 #set y val
    if i >=5:
      lightpost.sety(y_val-(150/i)*7) #move y cord down
    elif i >=3:
      lightpost.sety(y_val-(150/i)*13) #move y cord down
  lightpost.setx(x_val) #go set x val

  many_lamps.append(lightpost) #add turtle to many_lamps list

gas = turtle.Turtle() #create a gas turtle 
gas.pu() #pen up
gas.shape(gas_levels[0]) #set shape to gasindicatorfull
gas.goto(65,260) #move gas indicator to the bottom of the screen

#------------Functions----------------

def stop_movement(): #create function: stop player movement
  player.direction = "stop" #initialize player direction

def move_left(): #create function: start left player movement
  player.direction = "left" #initialize player direction

def move_right(): #create function: start right player movement
  player.direction = "right" #initialize player direction

def playerDirection(): #move player
  if player.direction == "left": #check if direction is left
    if player.xcor() > -565: #keep moving if greater than -560 (keep player within game screen)
      int_x = player.xcor() #get the player current x pos
      int_x -=2 #take 1 away to move left
      player.setx(int_x) #set player x pos to the x val
  elif player.direction == "right": #check if direction is right
    if player.xcor() <= 560: #keep moving if less than 560 (keep player within game screen)
      int_x = player.xcor() #get the player current x pos
      int_x +=2 #take 1 away to move right
      player.setx(int_x) #set player x pos to the x val

def check_keys():
  wn.listen() #add a listen key for key pressed
  wn.onkeypress(move_left, "a") #left arrow key call
  wn.onkeypress(move_right, "d") #right arrow key call
  wn.onkeyrelease(stop_movement, "a") #if not held down, stop moving
  wn.onkeyrelease(stop_movement, "d") #if not held down, stop moving

  wn.onkeyrelease(car_skin, "s") #on release of key, switch colour lists
  

def car_skin():
  global change #global variable
  global change_count #global variable
  
  change_count+=1 #change to next avaliable colour 
  if change_count == 0:
    change = "yellow" #set yellow
  elif change_count == 1:
    change = "pink" #set pink
  elif change_count == 2:
    change = "orange" #set orange
  elif change_count>2:
    change_count = -1 #reset to yellow if out of colour options(adds 1 on new loop, -1 is to account for that)

def check_change():
  if change == "yellow":
    player.shape(car_state[lives]) #upon impact, damage car appearance
  elif change == "pink":
    player.shape(pinkcar_state[lives]) #upon impact, damage car appearance
  elif change == "orange":
    player.shape(orangecar_state[lives]) #upon impact, damage car appearance

def move_enemies(): #move down
  global lives #declare as global variable
  for k in range(0,4):
    check_change() #call colour change function
    int_y=many_enemies[k].ycor()  #set inty to value of ycor
    int_y-=many_enemies[k].speed/2 #go down by q amount
    many_enemies[k].sety(int_y) #move turtle to y
    if int_y <= -350: #checking if enemy has reached the bottom
      
      int_x = random.choice(down_lane)#select random spawn lane
      many_enemies[k].sety(350) #move back to the top
      many_enemies[k].setx(int_x) #move back to the top 
      car_colour = random.choice(enemy_colours) #select random car colour
      many_enemies[k].shape(car_colour) #set shape (120x120 pixels)
    if many_enemies[k].distance(player) < 90: #check distance from enemy to player
      
      int_x = random.choice(down_lane)#select random spawn lane
      many_enemies[k].goto(int_x,350) #go back to top
      
      lives -=1 #remove a life
      for i in range(lives):
        many_lives[i].ht() #remove heart turtle from list
      
      check_change() #call colour change function

      
      car_colour = random.choice(enemy_colours) #select random car colour
      many_enemies[k].shape(car_colour) #set shape (120x120 pixels)

  for k in range(5,8):
    int_y=many_enemies[k].ycor()  #set inty to value of ycor
    int_y+=many_enemies[k].speed/2 #go down by q amount
    many_enemies[k].sety(int_y) #move turtle to y
    if int_y >= 350: #checking if enemy has reached the top
      
      int_x = random.choice(up_lane)
      many_enemies[k].sety(-350) #move back to the top
      many_enemies[k].setx(int_x) #move back to the top 
      car_colour = random.choice(enemy_colours) #select random car colour
      many_enemies[k].shape(car_colour) #set shape (120x120 pixels)
      
    if many_enemies[k].distance(player) < 90: #check distance from enemy to player
      
      int_x = random.choice(up_lane) #select random lane from up list
      many_enemies[k].goto(int_x,-350) #go back to top
      
      lives -=1 #remove a life
      for i in range(lives):
        many_lives[i].ht() #remove heart turtle from list

      check_change() #call colour change function
      
      car_colour = random.choice(enemy_colours) #select random car colour
      many_enemies[k].shape(car_colour) #set shape (120x120 pixels)

def move_tools(): #move down
  global int_score #declare as global variable
  for tool in many_tools:
    int_y=tool.ycor()  #set inty to value of ycor
    int_y-=tool.speed/2 #go down by q amount
    tool.sety(int_y) #move turtle to y
    if int_y <= -350: #checking if tool has reached the bottom
      int_x = random.choice(lane_x) #select random spawn lane
      tool.sety(350) #move back to the top
      tool.setx(int_x) #move back to the top 

    if tool.distance(player) < 90: #check distance from tool to player
      int_x = random.choice(lane_x) #select random spawn lane
      tool.goto(int_x,350) #go back to top

      int_score += 10 #add 10 to score

def move_gas(): #move gas cans down
  global int_gas
  for gas_can in many_cans:
    int_y = gas_can.ycor() #set int_y to value of ycor
    int_y -= gas_can.speed/1.5 #reduce speed by half 
    gas_can.sety(int_y) #move turtle to int_y
    if int_y <= -350: #checking if gas can has reached the bottom
      int_x = random.choice(lane_x) #select random spawn lane
      gas_can.sety(350) #move back to the top
      gas_can.setx(int_x) #move back to the top 
    
    if gas_can.distance(player) < 90: #check distance from gas_can to player
      int_x = random.choice(lane_x) #select random spawn lane
      gas_can.goto(int_x,350) #go back to top

      if int_gas < 40:
        int_gas += 10 #add 10 to gas


def police_stamp():
  police_xcor = player.xcor() - 70 #subtract 10 from the player's x-coordinate
  
  if -106< player.xcor() <137:
    police.goto(police_xcor,-200) #move police to the bottom of the screen beside the player
  elif 298< player.xcor() <323:
    police.goto(police_xcor,-200) #move police to the bottom of the screen beside the player
  elif 504< player.xcor():
    police.goto(police_xcor,-200) #move police to the bottom of the screen beside the player
  elif -335< player.xcor() <-303:
    police.goto(police_xcor,-200) #move police to the bottom of the screen beside the player
  elif player.xcor() <-504:
    police.goto(police_xcor,-200) #move police to the bottom of the screen beside the player
  else:
    police.goto(1500,200) # move police off the screen
  

def hide_police():
  if -303< player.xcor() <-105:
    police.ht()
  elif -502< player.xcor() <-334:
    police.ht()
  elif 138< player.xcor() <300:
    police.ht()
  elif 330< player.xcor() <505:
    police.ht()

def move_plants(): #move down
  for plant in many_plants:
    int_y=plant.ycor()  #set inty to value of ycor
    int_y-=1.5 #go down by 1.5
    plant.sety(int_y) #move turtle to y
    if int_y <= -350: #checking if plant has reached the bottom
      plant.sety(350) #move back to the top

def move_lamps(): #move down
  for lightpost in many_lamps:
    int_y=lightpost.ycor()  #set inty to value of ycor
    int_y-=1.5 #go down by 1.5
    lightpost.sety(int_y) #move turtle to y
    if int_y <= -350: #checking if lightpost has reached the bottom
      lightpost.sety(350) #move back to the top

def game_over():
  pen.clear() #clear turtle
  player.ht() #hide turtle
  gas.ht() #hide turtle
  police.ht() # hide turtle
  for enemy in many_enemies: 
    enemy.ht() #hide turtle
  for life in many_lives:
    life.ht() #hide turtle
  for tool in many_tools:
    tool.ht() #hide turtle
  for plant in many_plants:
    plant.ht() #hide turtle
  for lightpost in many_lamps:
    lightpost.ht() #hide turtle
  for gas_can in many_cans:
    gas_can.ht() # hide turtle


def gas_amount():
  global int_gas 
  #print(int_gas) # print the gas values for testing
  int_gas -= 0.05 # subtract 0.05 from int_gas
  if int_gas >= 40: # if the gas level is greater than or equal to 40
    gas.shape(gas_levels[0]) # set the gas turtle shape to gasindicatorfull
  elif int_gas >= 35: # if the gas level is less than or equal to 35
    gas.shape(gas_levels[1]) # set the gas turtle shape to gasindicator2
  elif int_gas >= 30: # if the gas level is less than or equal to 30
    gas.shape(gas_levels[2]) # set the gas turtle shape to gasindicator3
  elif int_gas >= 25: # if the gas level is less than or equal to 25
    gas.shape(gas_levels[3]) # set the gas turtle shape to gasindicator4
  elif int_gas >= 20: # if the gas level is less than or equal to 20
    gas.shape(gas_levels[4]) # set the gas turtle shape to gasindicator2
  elif int_gas >= 15: # if the gas level is less than or equal to 15
    gas.shape(gas_levels[5]) # set the gas turtle shape to gasindicator2
  elif int_gas >= 10: # if the gas level is less than or equal to 10
    gas.shape(gas_levels[6]) # set the gas turtle shape to gasindicator2
  elif int_gas >= 5: # if the gas level is less than or equal to 5
    gas.shape(gas_levels[7]) # set the gas turtle shape to gasindicator2
  elif int_gas <= 0: # if there is no more gas
    gas.shape(gas_levels[8]) # set the gas turtle shape to gasindicatorempty
    time.sleep(2) #wait two seconds for player to see empty gas
    lives == 0 #set lives 0, exit continuous loop


def scroll_path(): #scroll the road
  global camera_dy #camera
  global camera_y #camera
  camera_dy = -1 #move camera down

def move_camera():
  global camera_y  #call global variable
  global camera_dy #call global variable
  global int_score #call global variable
  scroll_path() #call function
  police_stamp()

  camera_dy =-1 #move camera up
  camera_y += camera_dy #math to move camera
  camera_y %=800 #modulus to reset background
  
  path.sety(camera_y) #set a path
  path.stamp() #leave a copy
  for plant in many_plants:
    plant.stamp() #leave a copy
  for enemy in many_enemies:
    enemy.stamp() #leave a copy
  for gas_can in many_cans:
    gas_can.stamp() # leave a copy
  for lightpost in many_lamps:
    lightpost.stamp() #leave a copy
  for tool in many_tools:
    tool.stamp() #leave a copy
  for i in range(lives):
    many_lives[i].stamp()#leave a copy
  gas.stamp() #leave a copyyer.stamp() #leave a copy
  player.stamp() #leave a copy
  police.stamp()
  pen.write("Score:\t" + str(int_score), font= penstyle, align = "center") #Text to be printed, font, alignment


  path.sety(camera_y-800)#-800 is the path offset
  path.stamp() #leave copy
  for plant in many_plants:
    plant.stamp() #leave a copy
  for enemy in many_enemies:
    enemy.stamp() #leave a copy
  for gas_can in many_cans:
    gas_can.stamp() # leave a copy
  for lightpost in many_lamps:
    lightpost.stamp() #leave a copy
  for tool in many_tools:
    tool.stamp() #leave a copy
  for i in range(lives):
    many_lives[i].stamp()#leave a copy
  gas.stamp() #leave a copy
  player.stamp() #leave a copy
  police.stamp() # stamp police
  pen.write("Score:\t" + str(int_score), font= penstyle, align = "center") #Text to be printed, font, alignment
  
  
  wn.update() #update
  path.clear() #clear old copies
  for plant in many_plants:
    plant.clear() #clear old copies
  for enemy in many_enemies:
    enemy.clear() #clear old copies
  for gas_can in many_cans:
    gas_can.clear() # clear old copies
  for lightpost in many_lamps:
    lightpost.clear() #clear old copies
  for tool in many_tools:
    tool.clear() #clear old copies
  for i in range(lives):
    many_lives[i].clear() #clear old copies
  gas.clear() #clear old copies
  player.clear() #clear old copies
  police.clear() #clear old copies
  pen.clear() #clear pen print
  
#-------------------------- Main ------------------------
print("Game Instructions\n") # print game instructions
print("Press the s key to change your car colour. (Yellow, Pink, & Orange)") # print game instructions
print("Use a and d keys to navigate") # print game instructions
print("Collect Gas Cans to prolong your playtime.") # print game instructions
print("Collect Tools to get a higher score.") # print game instructions


while int_gas >= 0 and lives > 0: #loop 
  move_camera() #call function
  check_keys() #call function
  playerDirection() #call function to make player move
  move_tools() # call function to make tools move
  move_gas() # call function to make gas cans move
  move_enemies() #call function to make enemies move
  move_plants() #call function to make plants move
  move_lamps() #call function to make lamps move
  gas_amount() #call function to make the gas values add and subtract

#after lives over/out of gas, game over functions:
game_over() #call game over (hides all)
move_camera() #call function (cover)
pen.goto(15,0) #go to x y
pen.write("GAME OVER\nScore:\t" + str(int_score), font= penstyle, align = "center") #Text to be printed, font, alignment
